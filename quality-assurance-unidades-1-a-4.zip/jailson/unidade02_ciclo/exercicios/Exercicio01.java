package jailson.unidade02_ciclo.exercicios;

// Unidade 2, itens 27 a 29 — laboratório de QA no ciclo.
// A atividade original é teórica; o programa apresenta a resolução escrita.
public class Exercicio01 {
    public static void main(String[] args) {
        System.out.println("""
# U02 — Laboratório 2: QA antes do código
**Origem:** itens 27–29 · **Contexto:** cupom de desconto da FoodGo.

## Parte A — Perguntas sobre requisitos
1. Qual é a data e hora inicial e final de validade do cupom, com qual fuso e limites inclusivos?
2. Existe valor mínimo de pedido? Frete e taxas entram nesse cálculo?
3. Cada cupom representa percentual ou valor fixo? Como o tipo é identificado?
4. Qual é a base do percentual: total dos produtos elegíveis, total do carrinho ou outro valor?
5. Há teto monetário para o desconto e quais regras de arredondamento serão usadas?
6. Um desconto fixo maior que a base deve ser limitado, recusado ou tratado de outra forma?
7. Pode combinar cupom com outro cupom, promoção de produto ou benefício de frete?
8. Quais produtos, categorias, estabelecimentos ou regiões são elegíveis?
9. O benefício depende de usuário autenticado, primeira compra ou grupo específico?
10. Qual é o limite global e por cliente e quando uma utilização é contabilizada?
11. Cancelamento ou falha de pagamento devolve uma utilização ao limite?
12. Maiúsculas, minúsculas e espaços externos no código serão normalizados?
13. O que deve acontecer se o cliente alterar o carrinho após aplicar o cupom?
14. Que mensagens distinguem código inexistente, expirado, inelegível ou limite esgotado?
15. Em qual ponto o serviço revalida disponibilidade e validade: aplicação do cupom, confirmação do pedido ou ambos?
16. Como duas compras simultâneas disputando a última utilização serão tratadas?

## Parte B — Mapa de riscos
| ID | Risco | Impacto | Prioridade inicial |
|---|---|---|---|
| R01 | Aceitar cupom vencido | Desconto indevido e perda financeira | Alta |
| R02 | Desconto exceder a base e gerar total negativo | Cobrança incorreta e inconsistência contábil | Alta |
| R03 | Corrida no limite de utilizações | Benefício acima da quantidade autorizada | Alta |
| R04 | Percentual calculado sobre base errada | Desconto e cobrança incorretos | Alta |
| R05 | Cupom continuar aplicado após mudança incompatível no carrinho | Total final diferente da regra | Alta |
| R06 | Reenvio duplicar a aplicação | Desconto repetido | Alta |
| R07 | Arredondamento divergente entre tela e serviço | Valor cobrado diferente do exibido | Alta |
| R08 | Mensagem não explicar inelegibilidade | Abandono e suporte desnecessário | Média |
| R09 | Remover cupom não restaurar o total | Cobrança ou informação incorreta | Alta |
| R10 | Erro do serviço deixar interface travada | Impedimento de concluir o pedido | Alta |

## Parte C — Critérios de aceite propostos
**São propostas para refinamento com Produto e Desenvolvimento.** O enunciado não definiu percentuais, datas, limites ou fórmula final. Os critérios abaixo dependem da configuração aprovada de cada cupom, sem inventar valores numéricos.

### Reescrita dos três critérios originais
- **CA01 — Informar código:** dado o carrinho, ao informar um código e solicitar aplicação, encaminhar o código ao serviço e apresentar indicação de processamento. Código vazio deve receber orientação de preenchimento, conforme mensagem acordada.
- **CA02 — Aplicar desconto:** dado cupom existente, vigente e elegível segundo sua configuração aprovada, aplicar uma única vez o desconto calculado pela fórmula e pelo arredondamento definidos.
- **CA03 — Atualizar valor:** ao aplicar com sucesso, exibir base, desconto e total atualizado; os valores exibidos devem coincidir com o cálculo retornado pelo serviço.

### Cinco critérios adicionais
- **CA04 — Inelegibilidade:** ao receber código inexistente, vencido ou inelegível, preservar o total anterior e exibir o motivo permitido pela política de mensagens.
- **CA05 — Remoção:** ao remover um cupom aplicado, retirar o desconto e recalcular o pedido pela regra vigente, preservando os demais componentes.
- **CA06 — Reenvio:** cliques ou requisições repetidos referentes à mesma aplicação não podem acumular o mesmo desconto.
- **CA07 — Alteração do carrinho:** após mudança de itens, reavaliar elegibilidade e recalcular; se o cupom deixar de ser elegível, informar e remover o desconto.
- **CA08 — Falha de comunicação:** diante de falha ao aplicar, preservar valores confirmados e apresentar erro e possibilidade de nova tentativa sem duplicação.

**Dados a obter antes de executar:** configuração do cupom, datas e fuso, elegibilidade, mínimo, teto, usos, cumulatividade, fórmula, arredondamento e mensagens. A conformidade só pode ser confirmada depois desse acordo.

## Parte D — Análise do protótipo
### A. Dúvidas para designer e time
Como ficam botão e campo durante o carregamento? A pessoa pode tentar de novo? Onde aparecem sucesso e erro e como são anunciados? Como remover um cupom? O código digitado será preservado quando o serviço falhar? Como os valores anteriores permanecem compreensíveis no celular?

### B. Estados adicionais
- Inicial, campo vazio e campo preenchido.
- Validando ou aguardando serviço.
- Aplicado com sucesso, com desconto discriminado e ação de remover.
- Inexistente, expirado, inelegível e limite de usos atingido.
- Falha de comunicação, com tentativa posterior.
- Cupom removido e cupom invalidado por mudança do carrinho.

### C. Utilidade antes do Front-end
Comparar os estados com os critérios evita que a equipe implemente apenas a tela de sucesso. O time pode alinhar mensagens, acessibilidade, contratos do serviço e consistência de valores antes que alterações exijam refazer componentes.

## Parte E — Atuação de QA no ciclo
| Momento | Ação 1 | Ação 2 |
|---|---|---|
| Requisitos | Investigar validade, cálculo e elegibilidade | Revisar critérios com exemplos e limites |
| Design | Conferir estados de sucesso, carregamento e erro | Avaliar foco, mensagens e telas pequenas |
| Desenvolvimento | Discutir cenários de limite com quem implementa | Revisar contrato e preparar dados controlados |
| Antes da liberação | Executar cenários positivos, negativos e de repetição | Conferir valores e riscos restantes com evidências |
| Depois da liberação | Acompanhar indicadores e relatos autorizados | Correlacionar incidentes e propor melhorias para o próximo ciclo |

## Parte F — Reflexão (10 linhas)
Um requisito pode conter interpretações incompatíveis antes de existir implementação.  
Ao perguntar o que torna um cupom válido, QA revela decisões que ainda não foram tomadas.  
Exemplos de datas, limites e valores ajudam o time a discutir resultados concretos.  
A revisão do protótipo evidencia estados de erro e carregamento ausentes.  
A comparação entre tela e contrato pode antecipar inconsistências de cálculo.  
O mapa de riscos ajuda a priorizar dúvidas com maior impacto.  
Essas ações previnem que interpretações diferentes virem código e retrabalho.  
Desenvolvedores, Produto e Design participam da construção das respostas.  
Depois da implementação, os testes verificam se o acordo foi atendido.  
Antecipar qualidade melhora o processo e complementa a verificação do produto.

## Checklist
16 perguntas, 10 riscos, 3 critérios reescritos, 5 adicionais, análise de estados, 2 ações por etapa e reflexão. Regras ainda não aprovadas estão identificadas como propostas.

""");
    }
}
