package jailson.unidade02_ciclo.exercicios;

// Unidade 2, itens 30 — desafio de finalizar pedido.
// A atividade original é teórica; o programa apresenta a resolução escrita.
public class Exercicio02 {
    public static void main(String[] args) {
        System.out.println("""
# U02 — Desafio: o botão Finalizar pedido
**Origem:** itens 30–31. **Requisito recebido:** o cliente poderá finalizar o pedido.

## Dez perguntas prioritárias (ordem de investigação nos 15 minutos simulados)
1. Quais são as condições obrigatórias para finalizar: carrinho, identificação, endereço e forma de pagamento?
2. Qual valor é definitivo para cobrança, incluindo produtos, descontos, frete e taxas?
3. Como a mesma intenção de compra é identificada para impedir pedidos e pagamentos duplicados?
4. O que deve ocorrer quando o pagamento é aprovado e a confirmação do pedido falha?
5. Estoque é reservado em qual momento e como se trata indisponibilidade na confirmação?
6. Quais resultados do pagamento são possíveis e como cada um altera o estado do pedido?
7. Como o sistema e o cliente distinguem uma falha de um pagamento ainda pendente?
8. Se houver perda de conexão, como consultar a situação antes de reenviar a compra?
9. O cliente precisa estar autenticado ou pode comprar como visitante? Como o pedido fica vinculado à pessoa correta?
10. Que confirmação e identificação do pedido serão exibidas e quais informações permitirão acompanhá-lo?

## Cinco riscos críticos
| Risco | Nível inicial | Justificativa |
|---|---|---|
| Cobrar duas vezes a mesma intenção de compra | Alto | Prejuízo financeiro, disputa e perda de confiança |
| Cobrar sem criar pedido recuperável | Alto | Cliente paga sem ter entrega ou acompanhamento garantido |
| Cobrar valor divergente do confirmado | Alto | Divergência financeira direta, especialmente com frete e descontos |
| Vender item sem disponibilidade | Alto | Compromisso de entrega que pode não ser atendido |
| Associar pedido à pessoa errada | Alto | Exposição de dados e atendimento ou entrega incorretos |

Todos foram classificados como altos pelo impacto potencial; não há dados suficientes para estimar probabilidade. A prioridade deverá ser refinada com o time.

## Cinco critérios iniciais para validar com o time
1. Com condições obrigatórias satisfeitas, ao confirmar uma compra, gerar um identificador de pedido e apresentar seu estado conforme o resultado do pagamento.
2. O valor encaminhado para cobrança deve coincidir com o valor final confirmado pelo cliente; se houver mudança, solicitar nova confirmação.
3. Repetir a confirmação da mesma intenção de compra não deve produzir outro pedido nem uma cobrança adicional.
4. Uma recusa definitiva de pagamento não deve apresentar o pedido como pago; mostrar o estado e a orientação definidos para o motivo.
5. Havendo aprovação do pagamento seguida de falha na confirmação do pedido, manter referências correlacionáveis e permitir reconciliação e consulta de estado, sem reenviar automaticamente uma cobrança.

Os critérios são propostas. Ainda precisam de definição dos estados, condições, mensagens e mecanismo de reconciliação.

## Decisão fundamentada
A implementação completa do checkout deve aguardar pelo menos o acordo sobre valor final, identificação da intenção de compra, estados do pagamento, disponibilidade e tratamento de aprovação sem pedido. Essas lacunas afetam integridade financeira e não podem ficar a cargo de uma interpretação isolada. A equipe pode iniciar atividades independentes, como estruturar uma tela estática ou investigar a integração em ambiente de teste, enquanto Produto, Desenvolvimento e QA refinam esses pontos. Começar sem resolver as dúvidas críticas pode transformar um requisito curto em cobrança duplicada ou compra sem entrega.

""");
    }
}
