package jailson.unidade02_ciclo.exercicios;

// Unidade 2, itens 35 — atividade de recuperação.
// A atividade original é teórica; o programa apresenta a resolução escrita.
public class Exercicio03 {
    public static void main(String[] args) {
        System.out.println("""
# U02 — Recuperação: reserva de salas
**Origem:** item 35.

## Oito perguntas de esclarecimento
1. Quem pode reservar e quais permissões são necessárias?
2. Disponibilidade considera qual data, intervalo de horário e fuso?
3. Qual duração mínima e máxima e como tratar intervalos encostados?
4. Duas solicitações simultâneas para a mesma sala e horário podem ser aceitas?
5. Existe limite de antecedência, quantidade de reservas ou horário de funcionamento?
6. Capacidade e equipamentos devem limitar quais salas são apresentadas?
7. Como funcionam cancelamento, alteração e liberação do intervalo reservado?
8. Quais confirmação, mensagens de conflito e retorno de erro o usuário deve receber?

## Cinco riscos
| Risco | Impacto |
|---|---|
| Reservas sobrepostas | Duas equipes ocuparem a mesma sala |
| Reserva para horário passado ou com fim anterior ao início | Agenda inconsistente |
| Atualização atrasada de disponibilidade | Usuário escolher intervalo que já deixou de estar livre |
| Falha após salvar sem confirmação | Repetição e dúvida sobre a existência da reserva |
| Pessoa sem permissão reservar ou cancelar | Uso indevido e interrupção de reuniões |

## Cinco critérios propostos para validação
1. Uma solicitação autorizada para intervalo válido e disponível deve gerar uma reserva identificável, com sala e horários confirmados.
2. Solicitação que conflite com reserva confirmada não deve gerar uma segunda reserva sobreposta.
3. Em duas solicitações simultâneas conflitantes, somente uma pode confirmar; a outra deve receber o retorno de indisponibilidade acordado.
4. Uma falha na confirmação deve permitir consultar o estado da solicitação antes de reenviar, evitando duplicidade.
5. Cancelamento autorizado deve atualizar o estado e a disponibilidade conforme a regra acordada, sem alterar reservas de terceiros.

## Contribuição antes da implementação
QA pode comparar regras, exemplos de intervalos e protótipo, evidenciando ambiguidade sobre concorrência, fuso, permissões e cancelamento. Os critérios são discutidos com o time antes de se tornarem testes.

## Duas contribuições durante o desenvolvimento
1. Preparar dados controlados de reservas adjacentes e sobrepostas e revisar cenários de concorrência.
2. Alinhar com Desenvolvimento os contratos, mensagens e formas de observar o estado de uma solicitação.

## Duas verificações antes da liberação
1. Tentar confirmar simultaneamente o mesmo intervalo e conferir reserva, retorno e agenda.
2. Executar criação, consulta e cancelamento autorizado, incluindo falha de comunicação, para conferir estados e recuperação.

""");
    }
}
