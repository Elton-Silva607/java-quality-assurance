package jailson.unidade02_ciclo.exercicios;

// Diagnóstico da disciplina; as respostas são apresentadas no console.
public class Exercicio04 {
    public static void main(String[] args) {
        System.out.println("""
## Diagnóstico — item 5
| Questão | Resposta | Justificativa |
|---|---|---|
| 1 — QA somente após implementação | B — problemas identificados tardiamente | Uma interpretação errada pode exigir refazer várias partes. |
| 2 — senha forte | A — perguntar as regras | O critério precisa ser definido, não presumido. |
| 3 — identificar problemas em requisitos | D — diferentes membros da equipe | Produto, QA, Desenvolvimento e Design podem contribuir. |
| 4 — esperar código pronto | B — contribuir em requisitos e planejamento | Há artefatos e decisões que podem ser analisados antes do código. |
| 5 — prevenção | C — descobrir ambiguidade antes da implementação | Evita que a interpretação incorreta seja incorporada ao produto. |

""");
    }
}
