package jailson.unidade02_ciclo.exercicios;

// Teste de aprendizagem da disciplina; as respostas são apresentadas no console.
public class Exercicio05 {
    public static void main(String[] args) {
        System.out.println("""
## Teste de aprendizagem — item 32
| Questão | Resposta | Justificativa |
|---|---|---|
| 1 — atuação de QA no ciclo | B — diferentes etapas | QA pode revisar requisitos e contribuir no planejamento. |
| 2 — carregar rapidamente | B — falta de critério objetivo | Devem ser acordados tempo, carga e contexto, sem inventar um segundo como regra universal. |
| 3 — ação preventiva | C — identificar regra ambígua antes de implementar | A ação reduz risco antes da criação do defeito. |
| 4 — critérios de aceite | B — condições de comportamento para aceitação | Tornam o acordo verificável. |
| 5 — protótipo sem mensagem de erro | C — discutir inconsistência antes de implementar | O alinhamento precoce evita omissão e retrabalho. |
| 6 — Shift Left | C — introduzir qualidade mais cedo | Inclui revisão e prevenção e não elimina verificações posteriores. |
| 7 — cancelar quando necessário | B — esclarecer condições e regras | O prazo de sete dias não está definido pelo requisito apresentado. |
| 8 — responsabilidade | D — contribuição de diferentes membros | Cada área participa da qualidade por suas decisões e atividades. |
| 9 — vantagem do refinamento | B — reduzir interpretações incorretas | Reduz risco, sem garantir ausência completa de defeitos. |
| 10 — pagamento aprovado e pedido falho | A — preocupação com cenário de risco | A pergunta antecipa inconsistência entre serviços e seus impactos. |

""");
    }
}
