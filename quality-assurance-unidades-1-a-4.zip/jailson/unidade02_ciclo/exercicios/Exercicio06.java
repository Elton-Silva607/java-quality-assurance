package jailson.unidade02_ciclo.exercicios;

// Autoavaliação da Unidade 2.
public class Exercicio06 {
    public static void main(String[] args) {
        System.out.println("""
# U02 — Autoavaliação e conferência dos entregáveis

## Escala pessoal
1 — Ainda não consigo · 2 — Consigo com ajuda · 3 — Consigo sozinho · 4 — Consigo explicar para outra pessoa.

A marcação é pessoal: execute, altere um exemplo e explique o resultado antes de escolher o nível. As evidências abaixo apoiam essa decisão e não presumem a sua experiência.

| Competência | Evidência para estudar e demonstrar | Seu nível |
|---|---|---|
| Explicar o ciclo de desenvolvimento | 04_Questoes_Resolvidas.md | A marcar: 1 / 2 / 3 / 4 |
| Explicar contribuição de QA antes do código | Laboratório, partes D–F | A marcar: 1 / 2 / 3 / 4 |
| Identificar ambiguidade | Laboratório, parte A | A marcar: 1 / 2 / 3 / 4 |
| Perguntar sem inventar regras | Propostas de critérios identificadas | A marcar: 1 / 2 / 3 / 4 |
| Explicar prevenção e detecção | 04_Questoes_Resolvidas.md | A marcar: 1 / 2 / 3 / 4 |
| Explicar Shift Left | 04_Questoes_Resolvidas.md | A marcar: 1 / 2 / 3 / 4 |
| Criar critérios verificáveis | Laboratório, parte C | A marcar: 1 / 2 / 3 / 4 |
| Identificar riscos sem código | Laboratório, parte B e desafio | A marcar: 1 / 2 / 3 / 4 |

## Reflexão de apoio
- Explique com suas palavras uma regra e seu limite.
- Mostre uma evidência que confirma um cenário e diga o que ela não comprova.
- Identifique uma dúvida que precisaria ser resolvida com o time.
- Escolha um cenário, altere um dado e antecipe o resultado antes de executar.

## Conferência da entrega
As resoluções e as evidências estão relacionadas em MAPA_EXERCICIOS.md, na raiz do projeto. Confira o checklist do laboratório e, nas unidades com Java, compare matriz e saída do console. A rubrica do professor é a referência para atribuição de nota; este material não atribui nota oficial ou nível pessoal ao aluno.

""");
    }
}
