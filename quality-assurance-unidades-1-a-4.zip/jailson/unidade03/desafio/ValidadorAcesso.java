package jailson.unidade03.desafio;

/** U03, itens 61–63: regras independentes para autorização de acesso. */
public class ValidadorAcesso {
    public static boolean acessoPermitido(boolean ativo, boolean bloqueado, int tentativas, String perfil) {
        if (!ativo || bloqueado || tentativas < 0 || tentativas > 3) {
            return false;
        }
        // Comparar o literal com o parâmetro também trata null com segurança.
        return "ALUNO".equals(perfil) || "PROFESSOR".equals(perfil);
    }

    public static void main(String[] args) {
        System.out.println("A - aluno ativo: " + acessoPermitido(true, false, 1, "ALUNO"));
        System.out.println("B - inativo: " + acessoPermitido(false, false, 1, "ALUNO"));
        System.out.println("C - bloqueado: " + acessoPermitido(true, true, 1, "ALUNO"));
        System.out.println("D - quatro tentativas: " + acessoPermitido(true, false, 4, "ALUNO"));
        System.out.println("E - visitante: " + acessoPermitido(true, false, 1, "VISITANTE"));
    }
}
