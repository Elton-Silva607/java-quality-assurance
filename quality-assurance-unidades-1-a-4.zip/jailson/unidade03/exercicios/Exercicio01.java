package jailson.unidade03.exercicios;

// Unidade 3, itens 12 e 13: criar e executar o primeiro programa.
public class Exercicio01 {
    public static void main(String[] args) {
        System.out.println("Olá, Quality Assurance!");
    }
}
