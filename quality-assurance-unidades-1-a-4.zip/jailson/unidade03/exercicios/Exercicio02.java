package jailson.unidade03.exercicios;

import java.util.Scanner;

// Unidade 3, item 44: entrada de dados pelo teclado.
public class Exercicio02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite seu nome: ");
        String nome = scanner.nextLine();
        System.out.println("Olá, " + nome);
        scanner.close();
    }
}
