package jailson.unidade03.exercicios;

// Unidade 3, itens 45 a 55: validador inicial e quatro cenários do laboratório.
public class Exercicio03 {
    public static boolean emailPreenchido(String email) {
        return email != null && !email.trim().isEmpty();
    }

    public static boolean idadePermitida(int idade) {
        return idade >= 18;
    }

    public static boolean senhaValida(String senha) {
        return senha != null && senha.length() >= 8;
    }

    public static String avaliarCadastro(String email, int idade, String senha) {
        if (!emailPreenchido(email)) return "E-MAIL OBRIGATORIO";
        if (!idadePermitida(idade)) return "IDADE NAO PERMITIDA";
        if (!senhaValida(senha)) return "SENHA INVALIDA";
        return "CADASTRO PERMITIDO";
    }

    public static void main(String[] args) {
        System.out.println("Cadastro válido: " + avaliarCadastro("aluno@exemplo.com", 18, "qa123456"));
        System.out.println("E-mail vazio: " + avaliarCadastro("", 18, "qa123456"));
        System.out.println("Idade 17: " + avaliarCadastro("aluno@exemplo.com", 17, "qa123456"));
        System.out.println("Senha curta: " + avaliarCadastro("aluno@exemplo.com", 18, "123"));

        for (int idade = 16; idade <= 20; idade++) {
            System.out.println("Idade " + idade + " permitida: " + idadePermitida(idade));
        }
    }
}
