package jailson.unidade03.exercicios;

// Unidade 3, itens 58 e 59: acrescentar aceite dos termos ao cadastro.
public class Exercicio04 {
    public static String avaliarCadastro(String email, int idade, String senha, boolean termosAceitos) {
        if (email == null || email.trim().isEmpty()) return "E-MAIL OBRIGATORIO";
        if (idade < 18) return "IDADE NAO PERMITIDA";
        if (senha == null || senha.length() < 8) return "SENHA INVALIDA";
        if (!termosAceitos) return "TERMOS NAO ACEITOS";
        return "CADASTRO PERMITIDO";
    }

    public static void main(String[] args) {
        System.out.println("Aceitou: " + avaliarCadastro("aluno@exemplo.com", 20, "qa123456", true));
        System.out.println("Não aceitou: " + avaliarCadastro("aluno@exemplo.com", 20, "qa123456", false));
    }
}
