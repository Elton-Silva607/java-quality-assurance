package jailson.unidade03.exercicios;

// Unidade 3, item 60: duas regras escolhidas para o laboratório.
// Idade máxima: 120 anos; tamanho máximo da senha: 20 caracteres.
public class Exercicio05 {
    public static String avaliarCadastro(String email, int idade, String senha, boolean termosAceitos) {
        if (email == null || email.trim().isEmpty()) return "E-MAIL OBRIGATORIO";
        if (idade < 18 || idade > 120) return "IDADE NAO PERMITIDA";
        if (senha == null || senha.length() < 8 || senha.length() > 20) return "SENHA INVALIDA";
        if (!termosAceitos) return "TERMOS NAO ACEITOS";
        return "CADASTRO PERMITIDO";
    }

    public static void main(String[] args) {
        System.out.println("Válido 1: " + avaliarCadastro("a@exemplo.com", 18, "12345678", true));
        System.out.println("Válido 2: " + avaliarCadastro("b@exemplo.com", 30, "123456789012", true));
        System.out.println("Válido 3: " + avaliarCadastro("c@exemplo.com", 120, "12345678901234567890", true));
        System.out.println("Inválido 1 — e-mail: " + avaliarCadastro("", 18, "12345678", true));
        System.out.println("Inválido 2 — idade 17: " + avaliarCadastro("a@exemplo.com", 17, "12345678", true));
        System.out.println("Inválido 3 — idade 121: " + avaliarCadastro("a@exemplo.com", 121, "12345678", true));
        System.out.println("Inválido 4 — senha 7: " + avaliarCadastro("a@exemplo.com", 18, "1234567", true));
        System.out.println("Inválido 5 — senha 21: " + avaliarCadastro("a@exemplo.com", 18, "123456789012345678901", true));
        System.out.println("Termos recusados: " + avaliarCadastro("a@exemplo.com", 20, "12345678", false));
    }
}
