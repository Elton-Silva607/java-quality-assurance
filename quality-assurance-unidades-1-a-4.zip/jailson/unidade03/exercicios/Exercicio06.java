package jailson.unidade03.exercicios;

// Unidade 3, itens 61 a 63: desafio profissional de acesso.
public class Exercicio06 {
    public static boolean acessoPermitido(boolean ativo, boolean bloqueado, int tentativas, String perfil) {
        if (!ativo || bloqueado || tentativas < 0 || tentativas > 3) return false;
        return "ALUNO".equals(perfil) || "PROFESSOR".equals(perfil);
    }

    public static void main(String[] args) {
        System.out.println("A — aluno ativo: " + acessoPermitido(true, false, 1, "ALUNO"));
        System.out.println("B — usuário inativo: " + acessoPermitido(false, false, 1, "ALUNO"));
        System.out.println("C — usuário bloqueado: " + acessoPermitido(true, true, 1, "ALUNO"));
        System.out.println("D — quatro tentativas: " + acessoPermitido(true, false, 4, "ALUNO"));
        System.out.println("E — visitante: " + acessoPermitido(true, false, 1, "VISITANTE"));
        System.out.println("Limite de três tentativas: " + acessoPermitido(true, false, 3, "PROFESSOR"));
    }
}
