package jailson.unidade03.exercicios;

// Unidade 3, item 73: atividade de recuperação — validador de cupom.
public class Exercicio07 {
    public static boolean cupomValido(boolean ativo, double valorPedido, int utilizacoes, String codigo) {
        return ativo && Double.isFinite(valorPedido) && valorPedido >= 50
                && utilizacoes >= 0 && utilizacoes < 5 && "PROMO10".equals(codigo);
    }

    public static void main(String[] args) {
        System.out.println("Cupom válido: " + cupomValido(true, 80, 1, "PROMO10"));
        System.out.println("Cupom inativo: " + cupomValido(false, 80, 1, "PROMO10"));
        System.out.println("Pedido abaixo de R$ 50: " + cupomValido(true, 49.99, 1, "PROMO10"));
        System.out.println("Cinco utilizações: " + cupomValido(true, 80, 5, "PROMO10"));
        System.out.println("Código incorreto: " + cupomValido(true, 80, 1, "OUTRO"));
        System.out.println("Limite de R$ 50: " + cupomValido(true, 50, 4, "PROMO10"));
    }
}
