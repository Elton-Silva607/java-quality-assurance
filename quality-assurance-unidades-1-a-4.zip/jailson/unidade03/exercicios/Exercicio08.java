package jailson.unidade03.exercicios;

// Unidade 3, item 56: erro lógico no limite e sua correção.
public class Exercicio08 {
    public static void main(String[] args) {
        int idade = 18;
        boolean condicaoIncorreta = idade > 18;
        boolean condicaoCorrigida = idade >= 18;

        System.out.println("Regra: 18 anos ou mais.");
        System.out.println("Comparação idade > 18: " + condicaoIncorreta);
        System.out.println("Comparação idade >= 18: " + condicaoCorrigida);
        System.out.println("As duas expressões compilam, mas somente a segunda inclui 18.");
    }
}
