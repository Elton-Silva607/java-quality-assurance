package jailson.unidade03.exercicios;

/** Exemplos executáveis dos itens 24–43: tipos, operadores, decisões, laços e métodos. */
public class Exercicio09 {
    public static boolean maiorDeIdade(int idade) {
        return idade >= 18;
    }

    public static String saudacao(String nome) {
        return "Olá, " + nome;
    }

    public static void main(String[] args) {
        String nome = "Ana";
        int idade = 18;
        double nota = 8.5;
        boolean ativo = true;
        System.out.println(saudacao(nome));
        System.out.println("Nota: " + nota + " | soma: " + (idade + 2) + " | resto: " + (idade % 5));
        if (maiorDeIdade(idade) && ativo) {
            System.out.println("Acesso permitido");
        } else if (!ativo) {
            System.out.println("Usuário inativo");
        } else {
            System.out.println("Menor de idade");
        }
        String status = new String("APROVADO");
        System.out.println("Comparação por conteúdo: " + "APROVADO".equals(status));
        for (int i = 1; i <= 3; i++) {
            System.out.println("for: " + i);
        }
        int tentativa = 0;
        while (tentativa < 3) {
            tentativa++;
            System.out.println("while: " + tentativa);
        }
    }
}
