package jailson.unidade03.exercicios;

// Diagnóstico da disciplina; as respostas são apresentadas no console.
public class Exercicio10 {
    public static void main(String[] args) {
        System.out.println("""
## Diagnóstico — item 6
| Questão | Resposta | Justificativa |
|---|---|---|
| 1 — finalidade da variável idade | B — armazenar um valor | O nome identifica um dado utilizado no programa. |
| 2 — idade >= 18 | C — maior ou igual a 18 | O valor de limite está incluído. |
| 3 — if | B — decidir por condição | Um bloco é escolhido conforme um booleano. |
| 4 — repetição | A — executar uma ação diversas vezes | Evita repetir manualmente o mesmo comando. |
| 5 — funções | A — organizar e reutilizar comportamentos | Ajuda a separar responsabilidades; não elimina todos os erros. |

""");
    }
}
