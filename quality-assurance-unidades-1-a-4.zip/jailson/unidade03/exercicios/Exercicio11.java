package jailson.unidade03.exercicios;

// Teste de aprendizagem da disciplina; as respostas são apresentadas no console.
public class Exercicio11 {
    public static void main(String[] args) {
        System.out.println("""
## Teste de aprendizagem — item 70
| Questão | Resposta | Justificativa |
|---|---|---|
| 1 — Java e JavaScript | C — declaração explícita de tipos nos exemplos Java | São linguagens diferentes; ambas possuem lógica e variáveis. |
| 2 — public class Calculadora | D — Calculadora.java | O arquivo da classe pública deve ter o mesmo nome, com maiúsculas correspondentes. |
| 3 — idade inteira | B — int idade = 20; | int armazena o inteiro apresentado. |
| 4 — 18 ou mais | D — idade >= 18 | A comparação inclui exatamente 18. |
| 5 — conteúdo de String | B — status.equals("APROVADO") | equals compara conteúdo; no código entregue, literal.equals(valor) também protege contra null. |
| 6 — for de 1 a 3 | B — repetição com valores 1, 2 e 3 | O incremento encerra o laço após i = 3. |
| 7 — retorno do método maiorDeIdade | C — booleano | A expressão retorna true ou false. |
| 8 — javac Programa.java | C — compila código Java | O compilador produz bytecode a partir do fonte válido. |
| 9 — idade > 18 | B — possível erro lógico no limite | Compila, mas rejeita uma idade permitida pelo requisito. |
| 10 — compilação | C — pode compilar e ter erro lógico | Tipos e sintaxe não comprovam conformidade com as regras. |

""");
    }
}
