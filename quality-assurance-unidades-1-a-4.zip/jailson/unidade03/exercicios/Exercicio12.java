package jailson.unidade03.exercicios;

// Questões de QA e decisões.
public class Exercicio12 {
    public static void main(String[] args) {
        System.out.println("""
## Item 63 — Compilar significa estar correto?
Não. A compilação verifica aspectos estruturais, sintáticos e de tipos, mas não conhece a intenção completa de uma regra de negócio. A expressão idade > 18 é válida em Java e compila; para a regra “18 anos ou mais”, porém, rejeita um caso que deveria passar. É necessário comparar o comportamento com critérios definidos usando situações válidas, inválidas e nos limites. Os resultados reais dessa comparação estão em 02_Matriz_Resultados.md.

## Recuperação — qual cenário representa limite?
Pedido exatamente de R$ 50 está na fronteira inclusiva do valor mínimo. R$ 49,99 fica imediatamente abaixo, no domínio de centavos. Também são interessantes 4 utilizações, permitidas, e 5 utilizações, rejeitadas, pois a quantidade deve ser menor que 5.

## Decisões adicionais documentadas
- No item 60, as regras escolhidas são idade máxima de 120 anos e senha máxima de 20 caracteres. A unidade permite escolher essas duas regras.
- Quantidade negativa de tentativas ou usos é rejeitada como dado fora do domínio; não representa uma nova permissão de acesso.
- Valores monetários NaN e infinitos são rejeitados nos validadores.
- O cadastro exige e-mail preenchido, não valida seu formato completo. O caso “abc” passa deliberadamente nessa regra limitada. A checagem introdutória de @ aparece na Unidade 4.
- O desafio de acesso permite até 3 tentativas; a conta da Unidade 4 bloqueia após a terceira tentativa inválida. São enunciados distintos e não devem ser confundidos.

""");
    }
}
