package jailson.unidade03.exercicios;

// Autoavaliação da Unidade 3.
public class Exercicio13 {
    public static void main(String[] args) {
        System.out.println("""
# U03 — Autoavaliação e conferência dos entregáveis

## Escala pessoal
1 — Ainda não consigo · 2 — Consigo com ajuda · 3 — Consigo sozinho · 4 — Consigo explicar para outra pessoa.

A marcação é pessoal: execute, altere um exemplo e explique o resultado antes de escolher o nível. As evidências abaixo apoiam essa decisão e não presumem a sua experiência.

| Competência | Evidência para estudar e demonstrar | Seu nível |
|---|---|---|
| Explicar Java e JavaScript | 04_Questoes_Resolvidas.md | A marcar: 1 / 2 / 3 / 4 |
| Criar e executar classe Java | PrimeiroPrograma e registros em evidencias | A marcar: 1 / 2 / 3 / 4 |
| Declarar variáveis | FundamentosJava.java | A marcar: 1 / 2 / 3 / 4 |
| Utilizar condições | ValidadorCadastro.java | A marcar: 1 / 2 / 3 / 4 |
| Utilizar operadores lógicos | ValidadorAcesso.java | A marcar: 1 / 2 / 3 / 4 |
| Criar repetição | FundamentosJava.java | A marcar: 1 / 2 / 3 / 4 |
| Criar método | ValidadorCupom.java | A marcar: 1 / 2 / 3 / 4 |
| Interpretar erro de compilação | 03_Depuracao_Resultados.md | A marcar: 1 / 2 / 3 / 4 |
| Diferenciar compilação e lógica | LimiteIncorreto e LimiteCorrigido | A marcar: 1 / 2 / 3 / 4 |
| Alterar e testar novamente | Matriz dos casos de cadastro modificados | A marcar: 1 / 2 / 3 / 4 |

## Reflexão de apoio
- Explique com suas palavras uma regra e seu limite.
- Mostre uma evidência que confirma um cenário e diga o que ela não comprova.
- Identifique uma dúvida que precisaria ser resolvida com o time.
- Escolha um cenário, altere um dado e antecipe o resultado antes de executar.

## Conferência da entrega
As resoluções e as evidências estão relacionadas em MAPA_EXERCICIOS.md, na raiz do projeto. Confira o checklist do laboratório e, nas unidades com Java, compare matriz e saída do console. A rubrica do professor é a referência para atribuição de nota; este material não atribui nota oficial ou nível pessoal ao aluno.

""");
    }
}
