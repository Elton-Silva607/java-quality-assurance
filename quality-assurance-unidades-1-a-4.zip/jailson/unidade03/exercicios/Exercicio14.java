package jailson.unidade03.exercicios;

// Exercício de depuração.
public class Exercicio14 {
    public static void main(String[] args) {
        System.out.println("""
# U03 — Erros provocados e mensagens observadas

Execução real: 2026-10-30T18:34:19-03:00. As falhas abaixo são intencionais e isoladas.
Os arquivos .java.txt não fazem parte das raízes de código do IntelliJ.

## LimiteCorrigido

Compilador — exit code: 0

```text
(sem mensagens)
```

Execução — exit code: 0

```text
Idade 18: true
```

## LimiteIncorreto

Compilador — exit code: 0

```text
(sem mensagens)
```

Execução — exit code: 0

```text
Idade 18: false
```

## SemPontoVirgula

Compilador — exit code: 1

```text
C:\\Users\\Elton Silva\\Documents\\Codex\\2026-10-30\\acs\\outputs\\Java_Quality_Assurance\\build\\depuracao\\SemPontoVirgula\\SemPontoVirgula.java:3: error: ';' expected
        int idade = 18
                      ^
1 error
```

## TipoIncompativel

Compilador — exit code: 1

```text
C:\\Users\\Elton Silva\\Documents\\Codex\\2026-10-30\\acs\\outputs\\Java_Quality_Assurance\\build\\depuracao\\TipoIncompativel\\TipoIncompativel.java:3: error: incompatible types: String cannot be converted to int
        int idade = "dezoito";
                    ^
1 error
```

## VariavelInexistente

Compilador — exit code: 1

```text
C:\\Users\\Elton Silva\\Documents\\Codex\\2026-10-30\\acs\\outputs\\Java_Quality_Assurance\\build\\depuracao\\VariavelInexistente\\VariavelInexistente.java:9: error: cannot find symbol
        boolean resultado = avaliarCadastro(email, idades, senha);
                                                   ^
  symbol:   variable idades
  location: class VariavelInexistente
1 error
```

## Correções e interpretação

- SemPontoVirgula: acrescentar ; após int idade = 18. Erro de sintaxe, antes de executar.
- TipoIncompativel: usar int idade = 18; texto não pode ser atribuído diretamente ao int.
- VariavelInexistente: trocar idades por idade, nome realmente declarado.
- LimiteIncorreto: idade > 18 compila e retorna false para 18; trocar por >= inclui o limite.
- LimiteCorrigido: execução produz true para 18, conforme a regra. Os demais limites são conferidos na matriz.

""");
    }
}
