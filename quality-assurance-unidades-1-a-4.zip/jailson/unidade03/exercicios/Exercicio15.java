package jailson.unidade03.exercicios;

// Matriz do laboratório.
public class Exercicio15 {
    public static void main(String[] args) {
        System.out.println("""
# U03 — Matriz de resultados reais

Execução: 2026-10-30T18:34:19-03:00 (UTC−03:00). 39 verificações; 39 aprovadas.

Cada linha compara o valor esperado definido no cenário com o valor produzido pelo programa.
Na Unidade 4, uma sequência pode verificar várias propriedades do mesmo cenário.

| Caso / propriedade | Esperado | Obtido | Status |
|---|---|---|---|
| U03-INICIAL-01-cadastro-valido | CADASTRO PERMITIDO | CADASTRO PERMITIDO | APROVADO |
| U03-INICIAL-02-email-vazio | E-MAIL OBRIGATORIO | E-MAIL OBRIGATORIO | APROVADO |
| U03-INICIAL-03-menor | IDADE NAO PERMITIDA | IDADE NAO PERMITIDA | APROVADO |
| U03-INICIAL-04-senha-curta | SENHA INVALIDA | SENHA INVALIDA | APROVADO |
| U03-CAD-01-valido-18-senha8 | CADASTRO PERMITIDO | CADASTRO PERMITIDO | APROVADO |
| U03-CAD-02-valido-30-senha12 | CADASTRO PERMITIDO | CADASTRO PERMITIDO | APROVADO |
| U03-CAD-03-valido-120-senha20 | CADASTRO PERMITIDO | CADASTRO PERMITIDO | APROVADO |
| U03-CAD-04-email-vazio | E-MAIL OBRIGATORIO | E-MAIL OBRIGATORIO | APROVADO |
| U03-CAD-05-idade17 | IDADE NAO PERMITIDA | IDADE NAO PERMITIDA | APROVADO |
| U03-CAD-06-idade121 | IDADE NAO PERMITIDA | IDADE NAO PERMITIDA | APROVADO |
| U03-CAD-07-senha7 | SENHA INVALIDA | SENHA INVALIDA | APROVADO |
| U03-CAD-08-senha21 | SENHA INVALIDA | SENHA INVALIDA | APROVADO |
| U03-CAD-09-termos-false | TERMOS NAO ACEITOS | TERMOS NAO ACEITOS | APROVADO |
| U03-CAD-10-email-null | E-MAIL OBRIGATORIO | E-MAIL OBRIGATORIO | APROVADO |
| U03-CAD-11-email-espacos | E-MAIL OBRIGATORIO | E-MAIL OBRIGATORIO | APROVADO |
| U03-CAD-12-senha-null | SENHA INVALIDA | SENHA INVALIDA | APROVADO |
| U03-CAD-13-idade-negativa | IDADE NAO PERMITIDA | IDADE NAO PERMITIDA | APROVADO |
| U03-CAD-14-idade19 | CADASTRO PERMITIDO | CADASTRO PERMITIDO | APROVADO |
| U03-CAD-15-idade119 | CADASTRO PERMITIDO | CADASTRO PERMITIDO | APROVADO |
| U03-CAD-16-precedencia-email | E-MAIL OBRIGATORIO | E-MAIL OBRIGATORIO | APROVADO |
| U03-CAD-17-email-apenas-preenchido | CADASTRO PERMITIDO | CADASTRO PERMITIDO | APROVADO |
| U03-ACESSO-A-ativo-aluno | true | true | APROVADO |
| U03-ACESSO-B-inativo | false | false | APROVADO |
| U03-ACESSO-C-bloqueado | false | false | APROVADO |
| U03-ACESSO-D-tentativas4 | false | false | APROVADO |
| U03-ACESSO-E-visitante | false | false | APROVADO |
| U03-ACESSO-F-professor | true | true | APROVADO |
| U03-ACESSO-G-tentativas0 | true | true | APROVADO |
| U03-ACESSO-H-perfil-null | false | false | APROVADO |
| U03-ACESSO-I-negativas | false | false | APROVADO |
| U03-CUPOM-01-valido | true | true | APROVADO |
| U03-CUPOM-02-inativo | false | false | APROVADO |
| U03-CUPOM-03-49.99 | false | false | APROVADO |
| U03-CUPOM-04-cinco-usos | false | false | APROVADO |
| U03-CUPOM-05-codigo-incorreto | false | false | APROVADO |
| U03-CUPOM-06-exatamente50 | true | true | APROVADO |
| U03-CUPOM-07-null | false | false | APROVADO |
| U03-CUPOM-08-nao-finito | false | false | APROVADO |
| U03-CUPOM-09-usos-negativos | false | false | APROVADO |

""");
    }
}
