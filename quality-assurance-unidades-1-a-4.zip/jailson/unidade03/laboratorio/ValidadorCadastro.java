package jailson.unidade03.laboratorio;

/** U03, itens 45–60: laboratório, termos e duas regras escolhidas no exercício. */
public class ValidadorCadastro {
    // Escolhas didáticas do item 60: idade máxima 120 e senha máxima 20.
    public static final int IDADE_MAXIMA = 120;
    public static final int SENHA_MAXIMA = 20;

    public static boolean emailPreenchido(String email) {
        return email != null && !email.trim().isEmpty();
    }

    public static boolean idadePermitida(int idade) {
        return idade >= 18 && idade <= IDADE_MAXIMA;
    }

    public static boolean senhaValida(String senha) {
        return senha != null && senha.length() >= 8 && senha.length() <= SENHA_MAXIMA;
    }

    public static String avaliarCadastro(String email, int idade, String senha, boolean termosAceitos) {
        if (!emailPreenchido(email)) {
            return "E-MAIL OBRIGATORIO";
        }
        if (!idadePermitida(idade)) {
            return "IDADE NAO PERMITIDA";
        }
        if (!senhaValida(senha)) {
            return "SENHA INVALIDA";
        }
        if (!termosAceitos) {
            return "TERMOS NAO ACEITOS";
        }
        return "CADASTRO PERMITIDO";
    }

    public static void main(String[] args) {
        System.out.println("Resultado: " + avaliarCadastro("aluno@exemplo.com", 18, "qa123456", true));
        for (int idade = 16; idade <= 20; idade++) {
            System.out.println("Idade " + idade + " -> " + idadePermitida(idade));
        }
        System.out.println("Sem termos: " + avaliarCadastro("aluno@exemplo.com", 20, "qa123456", false));
    }
}
