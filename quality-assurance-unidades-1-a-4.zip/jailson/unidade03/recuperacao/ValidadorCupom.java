package jailson.unidade03.recuperacao;

/** U03, item 73: cupom ativo, pedido >= 50, menos de cinco usos e código exato. */
public class ValidadorCupom {
    public static boolean cupomValido(boolean ativo, double valorPedido, int utilizacoes, String codigo) {
        return ativo && Double.isFinite(valorPedido) && valorPedido >= 50.0
                && utilizacoes >= 0 && utilizacoes < 5 && "PROMO10".equals(codigo);
    }

    public static void main(String[] args) {
        System.out.println("Pedido de R$ 50: " + cupomValido(true, 50.0, 0, "PROMO10"));
        System.out.println("Pedido de R$ 49,99: " + cupomValido(true, 49.99, 0, "PROMO10"));
        System.out.println("Cinco usos: " + cupomValido(true, 80.0, 5, "PROMO10"));
    }
}
