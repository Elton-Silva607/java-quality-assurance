package jailson.unidade04.desafio;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/** U04, itens 59–61. A lista impede a remoção de itens inexistentes. */
public class Carrinho {
    private final List<BigDecimal> itens = new ArrayList<>();
    private int quantidadeItens;
    private BigDecimal valorTotal = BigDecimal.ZERO;
    private boolean ativo = true;

    public int getQuantidadeItens() { return quantidadeItens; }
    public double getValorTotal() { return valorTotal.doubleValue(); }
    public boolean isAtivo() { return ativo; }

    public void adicionarItem(double valor) {
        if (!Double.isFinite(valor) || valor < 0) {
            return;
        }
        BigDecimal preco = BigDecimal.valueOf(valor);
        BigDecimal novoTotal = valorTotal.add(preco);
        if (!Double.isFinite(novoTotal.doubleValue())) {
            return;
        }
        itens.add(preco);
        quantidadeItens++;
        valorTotal = novoTotal;
    }

    public void removerItem(double valor) {
        if (!Double.isFinite(valor) || valor < 0) {
            return;
        }
        BigDecimal procurado = BigDecimal.valueOf(valor);
        for (int i = 0; i < itens.size(); i++) {
            if (itens.get(i).compareTo(procurado) == 0) {
                BigDecimal removido = itens.remove(i);
                quantidadeItens--;
                valorTotal = valorTotal.subtract(removido);
                return;
            }
        }
    }

    public boolean podeFinalizarCompra() {
        return ativo && quantidadeItens > 0 && valorTotal.signum() > 0;
    }

    public void desativar() { ativo = false; }
    public void ativar() { ativo = true; }

    public static void main(String[] args) {
        Carrinho carrinho = new Carrinho();
        System.out.println("Vazio: " + carrinho.podeFinalizarCompra());
        carrinho.adicionarItem(10.50);
        carrinho.adicionarItem(20.00);
        System.out.println("Itens: " + carrinho.getQuantidadeItens() + " | Total: " + carrinho.getValorTotal());
        System.out.println("Pode finalizar: " + carrinho.podeFinalizarCompra());
    }
}
