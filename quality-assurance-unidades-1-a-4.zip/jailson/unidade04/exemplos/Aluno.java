package jailson.unidade04.exemplos;

public class Aluno extends Usuario {
    private final String matricula;

    public Aluno(String nome, String matricula) {
        super(nome);
        this.matricula = matricula;
    }

    public String getMatricula() { return matricula; }
}
