package jailson.unidade04.exemplos;

public interface Notificador {
    void enviar(String mensagem);
}
