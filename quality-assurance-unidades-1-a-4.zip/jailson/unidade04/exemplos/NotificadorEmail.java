package jailson.unidade04.exemplos;

/** Apenas mostra uma mensagem no console; não envia e-mails reais. */
public class NotificadorEmail implements Notificador {
    @Override
    public void enviar(String mensagem) {
        System.out.println("Simulação de e-mail: " + mensagem);
    }
}
