package jailson.unidade04.exemplos;

public class Usuario {
    protected String nome;

    public Usuario(String nome) { this.nome = nome; }
    public String getNome() { return nome; }
}
