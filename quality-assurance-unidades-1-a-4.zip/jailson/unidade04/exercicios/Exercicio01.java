package jailson.unidade04.exercicios;

import jailson.unidade04.laboratorio.ContaUsuario;

// Unidade 4, itens 32 a 40: criar uma conta e observar seu estado inicial.
public class Exercicio01 {
    public static void main(String[] args) {
        ContaUsuario conta = new ContaUsuario("Ana", "ana@email.com", 20);
        System.out.println("Nome: " + conta.getNome());
        System.out.println("E-mail: " + conta.getEmail());
        System.out.println("Idade: " + conta.getIdade());
        System.out.println("Ativa: " + conta.isAtiva());
        System.out.println("Bloqueada: " + conta.isBloqueada());
        System.out.println("Tentativas: " + conta.getTentativasInvalidas());
        System.out.println("Pode acessar: " + conta.podeAcessar());
    }
}
