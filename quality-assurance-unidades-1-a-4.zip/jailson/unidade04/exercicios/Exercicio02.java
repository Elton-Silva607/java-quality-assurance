package jailson.unidade04.exercicios;

import jailson.unidade04.laboratorio.ContaUsuario;

// Unidade 4, itens 41 a 47 e laboratório 57: idade e limite de tentativas.
public class Exercicio02 {
    public static void main(String[] args) {
        for (int idade = 17; idade <= 19; idade++) {
            ContaUsuario conta = new ContaUsuario("Ana", "ana@email.com", idade);
            System.out.println("Idade " + idade + " pode acessar: " + conta.podeAcessar());
        }

        for (int quantidade = 0; quantidade <= 4; quantidade++) {
            ContaUsuario conta = new ContaUsuario("Ana", "ana@email.com", 20);
            for (int i = 0; i < quantidade; i++) {
                conta.registrarTentativaInvalida();
            }
            System.out.println(quantidade + " tentativa(s): bloqueada = " + conta.isBloqueada());
        }

        ContaUsuario conta = new ContaUsuario("Ana", "ana@email.com", 20);
        conta.desativar();
        System.out.println("Conta inativa pode acessar: " + conta.podeAcessar());
        conta.ativar();
        for (int i = 0; i < 3; i++) conta.registrarTentativaInvalida();
        conta.desbloquear();
        System.out.println("Depois do desbloqueio: " + conta.isBloqueada()
                + " | tentativas: " + conta.getTentativasInvalidas());
    }
}
