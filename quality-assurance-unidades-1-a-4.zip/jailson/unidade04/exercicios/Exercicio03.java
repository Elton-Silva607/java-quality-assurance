package jailson.unidade04.exercicios;

import jailson.unidade04.laboratorio.ContaUsuario;

// Unidade 4, item 57, etapas 5 e 6: alterar nome e e-mail com validação.
public class Exercicio03 {
    public static void main(String[] args) {
        ContaUsuario conta = new ContaUsuario("Ana", "ana@email.com", 20);
        conta.alterarEmail(null);
        conta.alterarEmail("sem-arroba");
        System.out.println("Após e-mails inválidos: " + conta.getEmail());

        conta.alterarEmail("  ana.nova@exemplo.com  ");
        System.out.println("E-mail válido: " + conta.getEmail());

        conta.alterarNome("   ");
        System.out.println("Após nome vazio: " + conta.getNome());
        conta.alterarNome("  Ana Maria  ");
        System.out.println("Nome sem espaços externos: " + conta.getNome());
    }
}
