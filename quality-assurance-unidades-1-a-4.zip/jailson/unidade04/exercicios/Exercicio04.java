package jailson.unidade04.exercicios;

import jailson.unidade04.laboratorio.PlanoCurso;

// Unidade 4, item 57, etapas 7 e 8: quatro planos de curso.
public class Exercicio04 {
    public static void main(String[] args) {
        PlanoCurso planoA = new PlanoCurso("Plano A", 40, true);
        PlanoCurso planoB = new PlanoCurso("Plano B", 0, true);
        PlanoCurso planoC = new PlanoCurso("Plano C", 60, false);
        PlanoCurso planoD = new PlanoCurso("Plano D", 1, true);

        System.out.println(planoA.getNome() + " pode ser ofertado: " + planoA.podeSerOfertado());
        System.out.println(planoB.getNome() + " pode ser ofertado: " + planoB.podeSerOfertado());
        System.out.println(planoC.getNome() + " pode ser ofertado: " + planoC.podeSerOfertado());
        System.out.println(planoD.getNome() + " pode ser ofertado: " + planoD.podeSerOfertado());
    }
}
