package jailson.unidade04.exercicios;

import jailson.unidade04.laboratorio.ContaUsuario;

// Unidade 4, item 58: suspensão temporária e quatro cenários.
public class Exercicio05 {
    public static void main(String[] args) {
        ContaUsuario conta = new ContaUsuario("Ana", "ana@email.com", 20);
        conta.suspender();
        System.out.println("1 — Suspensa pode acessar: " + conta.podeAcessar());

        conta.encerrarSuspensao();
        System.out.println("2 — Suspensão encerrada: " + conta.podeAcessar());

        conta.desativar();
        conta.suspender();
        conta.encerrarSuspensao();
        System.out.println("3 — Inativa após suspensão: " + conta.podeAcessar());

        ContaUsuario bloqueada = new ContaUsuario("Bia", "bia@email.com", 20);
        for (int i = 0; i < 3; i++) bloqueada.registrarTentativaInvalida();
        bloqueada.suspender();
        bloqueada.encerrarSuspensao();
        System.out.println("4 — Bloqueada após suspensão: " + bloqueada.podeAcessar());
    }
}
