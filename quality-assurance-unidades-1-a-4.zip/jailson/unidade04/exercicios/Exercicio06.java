package jailson.unidade04.exercicios;

import jailson.unidade04.desafio.Carrinho;

// Unidade 4, itens 59 e 60: desafio do carrinho, com oito cenários.
public class Exercicio06 {
    public static void main(String[] args) {
        Carrinho carrinho = new Carrinho();
        System.out.println("1 — Recém-criado pode finalizar: " + carrinho.podeFinalizarCompra());

        carrinho.adicionarItem(10);
        System.out.println("2 — Um item pode finalizar: " + carrinho.podeFinalizarCompra());

        carrinho.adicionarItem(20);
        System.out.println("3 — Vários itens: " + carrinho.getQuantidadeItens() + " | total: " + carrinho.getValorTotal());

        carrinho.desativar();
        System.out.println("4 — Inativo pode finalizar: " + carrinho.podeFinalizarCompra());

        carrinho.ativar();
        carrinho.adicionarItem(-10);
        System.out.println("5 — Após valor negativo, total: " + carrinho.getValorTotal());

        carrinho.removerItem(10);
        System.out.println("6 — Após remoção, total: " + carrinho.getValorTotal());

        Carrinho vazio = new Carrinho();
        vazio.removerItem(10);
        System.out.println("7 — Remoção de vazio, quantidade: " + vazio.getQuantidadeItens());

        Carrinho gratuito = new Carrinho();
        gratuito.adicionarItem(0);
        System.out.println("8 — Total zero pode finalizar: " + gratuito.podeFinalizarCompra());
    }
}
