package jailson.unidade04.exercicios;

import jailson.unidade04.recuperacao.ContaBancaria;

// Unidade 4, item 73: recuperação — conta bancária simplificada.
public class Exercicio07 {
    public static void main(String[] args) {
        ContaBancaria conta = new ContaBancaria("Ana", 0);
        System.out.println("Saldo inicial: " + conta.getSaldo());

        conta.depositar(100);
        System.out.println("Após depósito válido: " + conta.getSaldo());

        conta.depositar(-10);
        System.out.println("Após depósito negativo: " + conta.getSaldo());

        conta.sacar(101);
        System.out.println("Após saque superior ao saldo: " + conta.getSaldo());

        conta.desativar();
        conta.sacar(50);
        System.out.println("Após saque em conta inativa: " + conta.getSaldo());

        conta.ativar();
        conta.sacar(100);
        System.out.println("Após saque igual ao saldo: " + conta.getSaldo());
    }
}
