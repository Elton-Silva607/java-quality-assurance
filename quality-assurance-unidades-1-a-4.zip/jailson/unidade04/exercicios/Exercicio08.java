package jailson.unidade04.exercicios;

import jailson.unidade04.exemplos.Aluno;
import jailson.unidade04.exemplos.Notificador;
import jailson.unidade04.exemplos.NotificadorEmail;

// Unidade 4, itens 49 a 54: exemplos de herança e interface.
public class Exercicio08 {
    public static void main(String[] args) {
        Aluno aluno = new Aluno("Ana", "QA001");
        System.out.println("Nome herdado de Usuario: " + aluno.getNome());
        System.out.println("Matrícula: " + aluno.getMatricula());

        Notificador notificador = new NotificadorEmail();
        notificador.enviar("Exemplo de interface em Java");
    }
}
