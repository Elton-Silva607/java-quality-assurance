package jailson.unidade04.exercicios;

// Diagnóstico da disciplina; as respostas são apresentadas no console.
public class Exercicio09 {
    public static void main(String[] args) {
        System.out.println("""
## Diagnóstico — item 5
| Questão | Resposta | Justificativa |
|---|---|---|
| 1 — nome e idade | B — dois valores armazenados | Variáveis guardam dados. |
| 2 — método | A — comportamento ou operação | Métodos representam ações ou consultas. |
| 3 — centenas de variáveis para clientes | C — dificuldade de organização e manutenção | Objetos agrupam dados e operações relacionados. |
| 4 — comportamento | C — bloquearConta() | É uma operação, enquanto nome e idade são dados. |
| 5 — dado de usuário | C — idade | É um atributo do estado do usuário. |

""");
    }
}
