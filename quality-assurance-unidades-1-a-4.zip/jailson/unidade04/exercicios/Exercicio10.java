package jailson.unidade04.exercicios;

// Teste de aprendizagem da disciplina; as respostas são apresentadas no console.
public class Exercicio10 {
    public static void main(String[] args) {
        System.out.println("""
## Teste de aprendizagem — item 70
| Questão | Resposta | Justificativa |
|---|---|---|
| 1 — classe e objeto | B — estrutura e instância | A classe define; o objeto concretiza uma instância com estado próprio. |
| 2 — private int tentativas | C — atributo | Guarda estado da instância. |
| 3 — criar objeto | C — Usuario usuario = new Usuario(); | new chama a criação e inicialização da instância. |
| 4 — construtor | B — inicializar novo objeto | Define o estado inicial a partir dos parâmetros. |
| 5 — private | C — acesso direto restrito à própria classe | No contexto introdutório da unidade, impede alteração direta por outra classe. |
| 6 — this.email = email | A — atributo recebe parâmetro | this identifica o objeto atual. |
| 7 — limite de três tentativas | C — 2, 3 e 4 | Valores ao redor da transição ajudam a detectar comparação incorreta. |
| 8 — interface | B — contrato de comportamento implementado | Uma implementação fornece as operações do contrato. |
| 9 — chamada em referência null | B — sem objeto e possível erro em execução | A chamada mostrada provoca NullPointerException. |
| 10 — testabilidade | B — observar, controlar e verificar comportamento | Estado observável e operações claras ajudam os testes. |

""");
    }
}
