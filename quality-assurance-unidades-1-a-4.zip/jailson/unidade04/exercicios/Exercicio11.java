package jailson.unidade04.exercicios;

// Questões de orientação a objetos.
public class Exercicio11 {
    public static void main(String[] args) {
        System.out.println("""
## Parte E do entregável — conceitos
| Conceito | Explicação com o código entregue |
|---|---|
| Classe | Molde que define dados e comportamentos; por exemplo ContaUsuario. |
| Objeto | Instância criada por new ContaUsuario(...), com seus próprios dados. |
| Atributo | Dado de estado, como ativa, suspensa ou tentativasInvalidas. |
| Método | Operação ou consulta, como suspender() ou podeAcessar(). |
| Construtor | Inicializa o objeto; ContaUsuario(String, String, int) configura a conta ativa, desbloqueada, não suspensa e com zero tentativas. |
| Interface | Contrato como Notificador, cuja operação enviar é implementada por NotificadorEmail. A demonstração escreve no console. |
| Herança | Aluno extends Usuario reutiliza o nome da classe base; super(nome) chama seu construtor. |
| Encapsulamento | Campos privados são alterados por operações controladas, preservando regras. |
| null | Referência sem objeto; não equivale a uma conta desativada, vazia ou com zero tentativas. |
| Estado e comportamento | A tentativa inválida muda o contador e pode mudar bloqueio; podeAcessar consulta o estado sem modificá-lo. |

## Item 47 e laboratório — por que esses limites?
Nas tentativas, 2 ainda não bloqueia, 3 inicia o bloqueio e 4 deve continuar bloqueado. Nas idades, 17 não pode acessar, enquanto 18 e 19 podem quando as demais condições são satisfeitas. Esses conjuntos investigam a fronteira da mudança de comportamento.

## Item 48 — investigação do construtor
A classe base do material permite nome e e-mail vazios ou null e idade negativa. A evolução solicitada trata alterações de nome e e-mail, sem definir todas as regras de construção. Essa limitação foi preservada e documentada, sem inventar idade máxima na Unidade 4. Antes de uma aplicação real, o time precisaria definir invariantes de construção, política de rejeição e normalização. A regra de acesso continua impedindo menor de 18 anos.

## Parte F / item 61 — regras protegidas e responsabilidades de quem usa
**ContaUsuario:** protege campos privados; não libera acesso para menor, inativa, bloqueada ou suspensa; bloqueia no terceiro erro; preserva nome/e-mail ao receber alterações inválidas. Encerrar suspensão não ativa nem desbloqueia a conta. A validação de e-mail procura apenas @ e não comprova formato completo ou propriedade do endereço.

**Carrinho:** protege quantidade e total não negativos; rejeita preços negativos e não finitos; só remove uma ocorrência de item existente; permite finalizar somente ativo, não vazio e com total positivo. Guarda valores dos itens para impedir remoções fictícias e calcula valores decimais com BigDecimal. Não cria produtos, estoque, impostos nem integração de pagamento.

**Ainda depende do chamador:** autenticar e autorizar quem chama ativar, desbloquear e encerrarSuspensao; fornecer identidade e dados de construção corretos; encaminhar preços confiáveis e executar a confirmação real da compra. O exemplo local não implementa permissões, persistência, rede nem concorrência. O chamador precisa consultar podeAcessar antes de representar um acesso concedido.

## Recuperação — operações que alteram estado
depositar altera saldo quando recebe valor positivo e finito; sacar altera saldo quando a conta está ativa e o valor positivo não supera o saldo. ativar e desativar mudam a situação. podeSacar é apenas consulta. Depósitos na conta inativa foram mantidos permitidos porque o enunciado restringe explicitamente o saque; essa decisão está documentada, sem ampliar a restrição por suposição.

""");
    }
}
