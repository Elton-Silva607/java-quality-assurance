package jailson.unidade04.exercicios;

// Autoavaliação da Unidade 4.
public class Exercicio12 {
    public static void main(String[] args) {
        System.out.println("""
# U04 — Autoavaliação e conferência dos entregáveis

## Escala pessoal
1 — Ainda não consigo · 2 — Consigo com ajuda · 3 — Consigo sozinho · 4 — Consigo explicar para outra pessoa.

A marcação é pessoal: execute, altere um exemplo e explique o resultado antes de escolher o nível. As evidências abaixo apoiam essa decisão e não presumem a sua experiência.

| Competência | Evidência para estudar e demonstrar | Seu nível |
|---|---|---|
| Diferenciar classe e objeto | 04_Questoes_Resolvidas.md | A marcar: 1 / 2 / 3 / 4 |
| Criar objeto | ProgramaConta.java | A marcar: 1 / 2 / 3 / 4 |
| Identificar atributos e métodos | ContaUsuario.java | A marcar: 1 / 2 / 3 / 4 |
| Entender estado e comportamento | Matriz das tentativas | A marcar: 1 / 2 / 3 / 4 |
| Criar construtor | PlanoCurso.java | A marcar: 1 / 2 / 3 / 4 |
| Explicar this | ContaUsuario.java e conceitos | A marcar: 1 / 2 / 3 / 4 |
| Entender encapsulamento | Carrinho.java | A marcar: 1 / 2 / 3 / 4 |
| Utilizar private | AcessoPrivado e seu diagnóstico | A marcar: 1 / 2 / 3 / 4 |
| Reconhecer herança | Aluno extends Usuario | A marcar: 1 / 2 / 3 / 4 |
| Entender interface | Notificador e NotificadorEmail | A marcar: 1 / 2 / 3 / 4 |
| Criar objetos por cenário | TestesUnidade04.java | A marcar: 1 / 2 / 3 / 4 |
| Explicar null | ObjetoNulo e diagnóstico de execução | A marcar: 1 / 2 / 3 / 4 |

## Reflexão de apoio
- Explique com suas palavras uma regra e seu limite.
- Mostre uma evidência que confirma um cenário e diga o que ela não comprova.
- Identifique uma dúvida que precisaria ser resolvida com o time.
- Escolha um cenário, altere um dado e antecipe o resultado antes de executar.

## Conferência da entrega
As resoluções e as evidências estão relacionadas em MAPA_EXERCICIOS.md, na raiz do projeto. Confira o checklist do laboratório e, nas unidades com Java, compare matriz e saída do console. A rubrica do professor é a referência para atribuição de nota; este material não atribui nota oficial ou nível pessoal ao aluno.

""");
    }
}
