package jailson.unidade04.exercicios;

// Exercício de depuração.
public class Exercicio13 {
    public static void main(String[] args) {
        System.out.println("""
# U04 — Erros provocados e mensagens observadas

Execução real: 2026-10-30T18:34:19-03:00. As falhas abaixo são intencionais e isoladas.
Os arquivos .java.txt não fazem parte das raízes de código do IntelliJ.

## AcessoPrivado

Compilador — exit code: 1

```text
C:\\Users\\Elton Silva\\Documents\\Codex\\2026-10-30\\acs\\outputs\\Java_Quality_Assurance\\build\\depuracao\\AcessoPrivado\\AcessoPrivado.java:6: error: bloqueada has private access in ContaUsuario
        conta.bloqueada = true;
             ^
1 error
```

## ConstrutorIncorreto

Compilador — exit code: 1

```text
C:\\Users\\Elton Silva\\Documents\\Codex\\2026-10-30\\acs\\outputs\\Java_Quality_Assurance\\build\\depuracao\\ConstrutorIncorreto\\ConstrutorIncorreto.java:5: error: constructor ContaUsuario in class ContaUsuario cannot be applied to given types;
        ContaUsuario conta = new ContaUsuario("Ana");
                             ^
  required: String,String,int
  found:    String
  reason: actual and formal argument lists differ in length
1 error
```

## ObjetoNulo

Compilador — exit code: 0

```text
(sem mensagens)
```

Execução — exit code: 1

```text
Exception in thread "main" java.lang.NullPointerException: Cannot invoke "unidade04.laboratorio.ContaUsuario.podeAcessar()" because "<local1>" is null
	at ObjetoNulo.main(ObjetoNulo.java:6)
```

## Correções e interpretação

- AcessoPrivado: bloqueada é private. Usar as operações públicas apropriadas; não tornar o campo público.
- ConstrutorIncorreto: fornecer nome, e-mail e idade para a assinatura existente.
- ObjetoNulo: a referência não aponta para uma ContaUsuario. Criar uma instância antes da chamada ou tratar ausência explicitamente.
- Compilação verifica estrutura e tipos; a chamada em null é erro de execução; uma comparação de limite errada é erro lógico.

""");
    }
}
