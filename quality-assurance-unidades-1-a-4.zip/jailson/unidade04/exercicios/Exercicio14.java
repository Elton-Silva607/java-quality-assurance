package jailson.unidade04.exercicios;

// Matriz do laboratório.
public class Exercicio14 {
    public static void main(String[] args) {
        System.out.println("""
# U04 — Matriz de resultados reais

Execução: 2026-10-30T18:34:19-03:00 (UTC−03:00). 77 verificações; 77 aprovadas.

Cada linha compara o valor esperado definido no cenário com o valor produzido pelo programa.
Na Unidade 4, uma sequência pode verificar várias propriedades do mesmo cenário.

| Caso / propriedade | Esperado | Obtido | Status |
|---|---|---|---|
| U04-CONTA-01-inicial-ativa | true | true | APROVADO |
| U04-CONTA-02-inicial-desbloqueada | false | false | APROVADO |
| U04-CONTA-03-inicial-zero-tentativas | 0 | 0 | APROVADO |
| U04-CONTA-04-adulto-ativo-acessa | true | true | APROVADO |
| U04-LIMITE-0-bloqueio | false | false | APROVADO |
| U04-LIMITE-0-contador | 0 | 0 | APROVADO |
| U04-LIMITE-1-bloqueio | false | false | APROVADO |
| U04-LIMITE-1-contador | 1 | 1 | APROVADO |
| U04-LIMITE-2-bloqueio | false | false | APROVADO |
| U04-LIMITE-2-contador | 2 | 2 | APROVADO |
| U04-LIMITE-3-bloqueio | true | true | APROVADO |
| U04-LIMITE-3-contador | 3 | 3 | APROVADO |
| U04-LIMITE-4-bloqueio | true | true | APROVADO |
| U04-LIMITE-4-contador | 4 | 4 | APROVADO |
| U04-IDADE-17 | false | false | APROVADO |
| U04-IDADE-18 | true | true | APROVADO |
| U04-IDADE-19 | true | true | APROVADO |
| U04-CONTA-05-inativa | false | false | APROVADO |
| U04-CONTA-06-reativada | true | true | APROVADO |
| U04-CONTA-07-sucesso-zera-contador | 0 | 0 | APROVADO |
| U04-CONTA-08-desbloqueio | false | false | APROVADO |
| U04-CONTA-09-desbloqueio-zera | 0 | 0 | APROVADO |
| U04-SUSP-01-adulto-suspenso | false | false | APROVADO |
| U04-SUSP-02-retomada | true | true | APROVADO |
| U04-SUSP-03-retomada-nao-ativa-conta | false | false | APROVADO |
| U04-SUSP-04-retomada-nao-desbloqueia | false | false | APROVADO |
| U04-CONTA-10-sucesso-invalido-nao-zera | 3 | 3 | APROVADO |
| U04-SUSP-05-desbloqueio-nao-encerra-suspensao | false | false | APROVADO |
| U04-EMAIL-01-null-preserva | ana@email.com | ana@email.com | APROVADO |
| U04-EMAIL-02-vazio-preserva | ana@email.com | ana@email.com | APROVADO |
| U04-EMAIL-03-sem-arroba-preserva | ana@email.com | ana@email.com | APROVADO |
| U04-EMAIL-04-valido | novo@exemplo.com | novo@exemplo.com | APROVADO |
| U04-NOME-01-invalidos-preservam | Ana | Ana | APROVADO |
| U04-NOME-02-remove-espacos | Ana Maria | Ana Maria | APROVADO |
| U04-CONTA-11-objetos-independentes | Ana | Ana | APROVADO |
| U04-PLANO-1 | true | true | APROVADO |
| U04-PLANO-2 | false | false | APROVADO |
| U04-PLANO-3 | false | false | APROVADO |
| U04-PLANO-4 | true | true | APROVADO |
| U04-PLANO-5-desativado | false | false | APROVADO |
| U04-PLANO-6-reativado | true | true | APROVADO |
| U04-PLANO-7-negativo | false | false | APROVADO |
| U04-CARR-01-inicial-zero-itens | 0 | 0 | APROVADO |
| U04-CARR-02-inicial-total0 | 0.0 | 0.0 | APROVADO |
| U04-CARR-03-inicial-ativo | true | true | APROVADO |
| U04-CARR-04-vazio-nao-finaliza | false | false | APROVADO |
| U04-CARR-05-um-item | true | true | APROVADO |
| U04-CARR-06-varios-itens | 2 | 2 | APROVADO |
| U04-CARR-07-soma | 30.0 | 30.0 | APROVADO |
| U04-CARR-08-inativo | false | false | APROVADO |
| U04-CARR-09-negativo-preserva-total | 30.0 | 30.0 | APROVADO |
| U04-CARR-10-negativo-preserva-quantidade | 2 | 2 | APROVADO |
| U04-CARR-11-remocao-total | 20.0 | 20.0 | APROVADO |
| U04-CARR-12-remocao-itens | 1 | 1 | APROVADO |
| U04-CARR-13-inexistente-preserva | 20.0 | 20.0 | APROVADO |
| U04-CARR-14-remover-vazio | 0 | 0 | APROVADO |
| U04-CARR-15-esvaziado-total-zero | 0.0 | 0.0 | APROVADO |
| U04-CARR-16-item-gratis-total-zero | false | false | APROVADO |
| U04-CARR-17-nao-finitos-preservam | 1 | 1 | APROVADO |
| U04-CARR-18-decimais | 0.3 | 0.3 | APROVADO |
| U04-CARR-19-sem-residuo | 0.0 | 0.0 | APROVADO |
| U04-CARR-20-remove-uma-ocorrencia | 1 | 1 | APROVADO |
| U04-BANCO-01-zero | 0.0 | 0.0 | APROVADO |
| U04-BANCO-02-inicial-ativa | true | true | APROVADO |
| U04-BANCO-03-deposito-valido | 100.0 | 100.0 | APROVADO |
| U04-BANCO-04-deposito-negativo | 100.0 | 100.0 | APROVADO |
| U04-BANCO-05-saque-superior | 100.0 | 100.0 | APROVADO |
| U04-BANCO-06-inativa-preserva-saldo | 100.0 | 100.0 | APROVADO |
| U04-BANCO-07-inativa-pode-sacar | false | false | APROVADO |
| U04-BANCO-08-saque-igual-saldo | 0.0 | 0.0 | APROVADO |
| U04-BANCO-09-saque-zero | false | false | APROVADO |
| U04-BANCO-10-saque-negativo | 0.0 | 0.0 | APROVADO |
| U04-BANCO-11-deposito-nan | 0.0 | 0.0 | APROVADO |
| U04-BANCO-12-saldo-inicial-negativo | IllegalArgumentException | IllegalArgumentException | APROVADO |
| U04-BANCO-13-saldo-infinito | IllegalArgumentException | IllegalArgumentException | APROVADO |
| U04-EXEMPLO-heranca-super | Ana | Ana | APROVADO |
| U04-EXEMPLO-matricula | QA001 | QA001 | APROVADO |

""");
    }
}
