package jailson.unidade04.laboratorio;

/** U04, itens 33–58: classe evoluída, com e-mail, nome e suspensão temporária. */
public class ContaUsuario {
    private String nome;
    private String email;
    private final int idade;
    private boolean ativa;
    private boolean bloqueada;
    private int tentativasInvalidas;
    private boolean suspensa;

    public ContaUsuario(String nome, String email, int idade) {
        // O enunciado pede investigar o construtor, sem impor novas regras a ele.
        this.nome = nome;
        this.email = email;
        this.idade = idade;
        this.ativa = true;
        this.bloqueada = false;
        this.tentativasInvalidas = 0;
        this.suspensa = false;
    }

    public String getNome() { return nome; }
    public String getEmail() { return email; }
    public int getIdade() { return idade; }
    public boolean isAtiva() { return ativa; }
    public boolean isBloqueada() { return bloqueada; }
    public boolean isSuspensa() { return suspensa; }
    public int getTentativasInvalidas() { return tentativasInvalidas; }

    public boolean podeAcessar() {
        return idade >= 18 && ativa && !bloqueada && !suspensa;
    }

    public void registrarTentativaInvalida() {
        // Evita overflow do contador; a conta continua bloqueada após o limite.
        if (tentativasInvalidas < Integer.MAX_VALUE) {
            tentativasInvalidas++;
        }
        if (tentativasInvalidas >= 3) {
            bloqueada = true;
        }
    }

    public void registrarLoginComSucesso() {
        // Um sucesso só é válido em uma conta que tem acesso liberado.
        if (podeAcessar()) {
            tentativasInvalidas = 0;
        }
    }

    public void desativar() { ativa = false; }
    public void ativar() { ativa = true; }
    public void suspender() { suspensa = true; }
    public void encerrarSuspensao() { suspensa = false; }

    public void desbloquear() {
        bloqueada = false;
        tentativasInvalidas = 0;
    }

    public void alterarEmail(String novoEmail) {
        if (novoEmail == null || novoEmail.trim().isEmpty() || !novoEmail.contains("@")) {
            return;
        }
        email = novoEmail.trim();
    }

    public void alterarNome(String novoNome) {
        if (novoNome == null || novoNome.trim().isEmpty()) {
            return;
        }
        nome = novoNome.trim();
    }
}
