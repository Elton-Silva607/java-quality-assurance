package jailson.unidade04.laboratorio;

public class PlanoCurso {
    private final String nome;
    private final int cargaHoraria;
    private boolean ativo;

    public PlanoCurso(String nome, int cargaHoraria, boolean ativo) {
        this.nome = nome;
        this.cargaHoraria = cargaHoraria;
        this.ativo = ativo;
    }

    public String getNome() { return nome; }
    public int getCargaHoraria() { return cargaHoraria; }
    public boolean isAtivo() { return ativo; }
    public void ativar() { ativo = true; }
    public void desativar() { ativo = false; }

    public boolean podeSerOfertado() {
        return ativo && cargaHoraria > 0;
    }

    public static void main(String[] args) {
        PlanoCurso[] planos = {
                new PlanoCurso("Plano A", 40, true),
                new PlanoCurso("Plano B", 0, true),
                new PlanoCurso("Plano C", 60, false),
                new PlanoCurso("Plano D", 1, true)
        };
        for (PlanoCurso plano : planos) {
            System.out.println(plano.getNome() + " -> " + plano.podeSerOfertado());
        }
    }
}
