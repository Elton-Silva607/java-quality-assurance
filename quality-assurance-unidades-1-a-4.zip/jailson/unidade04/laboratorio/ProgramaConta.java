package jailson.unidade04.laboratorio;

public class ProgramaConta {
    public static void main(String[] args) {
        ContaUsuario conta = new ContaUsuario("Ana", "ana@email.com", 20);
        System.out.println("Usuário: " + conta.getNome());
        System.out.println("Pode acessar: " + conta.podeAcessar());
        conta.registrarTentativaInvalida();
        conta.registrarTentativaInvalida();
        conta.registrarTentativaInvalida();
        System.out.println("Tentativas: " + conta.getTentativasInvalidas());
        System.out.println("Bloqueada: " + conta.isBloqueada());
        System.out.println("Pode acessar: " + conta.podeAcessar());
        conta.desbloquear();
        conta.suspender();
        System.out.println("Suspensa: " + conta.isSuspensa() + " | Pode acessar: " + conta.podeAcessar());
        conta.encerrarSuspensao();
        System.out.println("Após encerrar suspensão: " + conta.podeAcessar());
    }
}
