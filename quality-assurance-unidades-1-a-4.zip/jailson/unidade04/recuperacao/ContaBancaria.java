package jailson.unidade04.recuperacao;

import java.math.BigDecimal;

/** Simulação local didática, sem conexão com qualquer banco ou serviço financeiro. */
public class ContaBancaria {
    private final String titular;
    private BigDecimal saldo;
    private boolean ativa = true;

    public ContaBancaria(String titular, double saldoInicial) {
        if (!Double.isFinite(saldoInicial) || saldoInicial < 0) {
            throw new IllegalArgumentException("Saldo inicial deve ser finito e não negativo");
        }
        this.titular = titular;
        this.saldo = BigDecimal.valueOf(saldoInicial);
    }

    public String getTitular() { return titular; }
    public double getSaldo() { return saldo.doubleValue(); }
    public boolean isAtiva() { return ativa; }
    public void ativar() { ativa = true; }
    public void desativar() { ativa = false; }

    public void depositar(double valor) {
        if (!Double.isFinite(valor) || valor <= 0) return;
        BigDecimal novoSaldo = saldo.add(BigDecimal.valueOf(valor));
        if (Double.isFinite(novoSaldo.doubleValue())) {
            saldo = novoSaldo;
        }
    }

    public boolean podeSacar(double valor) {
        return ativa && Double.isFinite(valor) && valor > 0
                && BigDecimal.valueOf(valor).compareTo(saldo) <= 0;
    }

    public void sacar(double valor) {
        if (podeSacar(valor)) {
            saldo = saldo.subtract(BigDecimal.valueOf(valor));
        }
    }

    public static void main(String[] args) {
        ContaBancaria conta = new ContaBancaria("Ana", 0);
        conta.depositar(50);
        conta.sacar(50);
        System.out.println("Saldo após depósito e saque: " + conta.getSaldo());
    }
}
